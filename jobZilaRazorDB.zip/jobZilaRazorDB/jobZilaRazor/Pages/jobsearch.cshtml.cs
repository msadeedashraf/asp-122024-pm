using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace jobZilaRazor.Pages
{
    public class jobsearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
