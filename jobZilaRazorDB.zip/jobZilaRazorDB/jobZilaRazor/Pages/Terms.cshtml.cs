using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace jobZilaRazor.Pages
{
    public class TermsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
