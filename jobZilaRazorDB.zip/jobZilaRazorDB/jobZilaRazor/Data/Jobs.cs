﻿namespace jobZilaRazor.Data
{
    public class Jobs
    {
        public int id { get; set; }
        public string title { get; set; }
        public string company { get; set; }
        public string  city { get; set; }
        public string description { get; set; }
    }
}
